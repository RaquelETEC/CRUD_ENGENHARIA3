
package eng3.fatec.core.aplicacao;

import Model.IEntidade;



public class EntidadeAplicacao implements IEntidade{

}
