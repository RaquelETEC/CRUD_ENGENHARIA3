package eng3.fatec.controle.web.vh.impl;

public interface IViewHelper {

}
