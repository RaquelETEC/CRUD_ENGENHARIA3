package eng3.fatec.core;


import Model.IEntidade;


public interface IStrategy 
{

	public String processar(IEntidade entidade);
	
}
