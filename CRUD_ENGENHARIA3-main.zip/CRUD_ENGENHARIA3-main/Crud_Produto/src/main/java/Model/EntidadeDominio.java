package Model;


import java.util.Date;

public class EntidadeDominio implements IEntidade{
	
	protected Integer id;

	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}

	
	

}
