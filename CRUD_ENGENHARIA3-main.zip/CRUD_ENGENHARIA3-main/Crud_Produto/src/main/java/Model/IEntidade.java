package Model;

public interface IEntidade {

}
